# index.py (your original code, with a small but critical fix)
import json
import boto3
import requests  # requests will be included in the deployment package
import datetime
import os  # Import os, you were using it without importing!

s3_client = boto3.client('s3')
ssm_client = boto3.client('ssm')
STOCKS = ["AAPL", "MSFT", "GOOGL", "AMZN", "META", "NVDA", "TSLA"]
API_URL = "https://api.stockdata.org/v1/data/quote"

def get_api_key():
    response = ssm_client.get_parameter(Name="STOCK_API_KEY", WithDecryption=True)
    return response['Parameter']['Value']

def fetch_stock_prices():
    API_KEY = get_api_key()
    params = {"symbols": ",".join(STOCKS), "api_token": API_KEY}
    response = requests.get(API_URL, params=params)
    if response.status_code == 200:
        return response.json()
    return None

def lambda_handler(event, context):
    stock_data = fetch_stock_prices()
    timestamp = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    filename = f"stock_prices_{timestamp}.json"

    if stock_data:
        s3_client.put_object(
            Bucket="magnificent7-stock-data-${AWS::AccountId}",
            Key=filename,
            Body=json.dumps(stock_data),
            ContentType="application/json"
        )

        log_data = {"timestamp": timestamp, "status": "Success", "file": filename}
        log_filename = f"log_{timestamp}.json"
        s3_client.put_object(
            Bucket="magnificent7-logs-${AWS::AccountId}",
            Key=log_filename,
            Body=json.dumps(log_data),
            ContentType="application/json"
        )

        return {"statusCode": 200, "body": "Stock data uploaded successfully."}
    else:
        print(f"Error fetching stock data. Status code: {response.status_code}, Response: {response.text}") # added to see the request error
        return {"statusCode": 500, "body": "Failed to fetch stock data."}